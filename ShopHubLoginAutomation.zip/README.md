
# ShopHub Login Automation Framework

## Overview

This project automates the login functionality of https://bugbash.syook.com using Selenium WebDriver and Cucumber BDD framework.

## Tech Stack

- Java
- Selenium WebDriver
- Cucumber BDD (Gherkin)
- JUnit
- Maven

## How to Run

1. Import the project into Eclipse or IntelliJ.
2. Run `TestRunner.java` as JUnit test.
3. View the test report in `target/cucumber-reports.html`.
