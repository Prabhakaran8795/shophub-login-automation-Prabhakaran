
package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.*;
import pages.LoginPage;
import static org.junit.Assert.*;

public class LoginSteps {
    WebDriver driver;
    LoginPage loginPage;

    @Given("User is on login page")
    public void user_is_on_login_page() {
        driver = new ChromeDriver();
        driver.get("https://bugbash.syook.com/");
        loginPage = new LoginPage(driver);
    }

    @When("User enters valid username {string} and password {string}")
    public void user_enters_valid_credentials(String username, String password) {
        loginPage.login(username, password);
    }

    @When("User enters invalid username {string} and password {string}")
    public void user_enters_invalid_credentials(String username, String password) {
        loginPage.login(username, password);
    }

    @And("clicks on login")
    public void clicks_on_login() {
        // Already handled in login method
    }

    @Then("User should be redirected to the dashboard")
    public void user_should_be_redirected_to_dashboard() {
        assertTrue(driver.getCurrentUrl().contains("dashboard"));
        driver.quit();
    }

    @Then("Error message should be displayed")
    public void error_message_should_be_displayed() {
        assertTrue(driver.getPageSource().contains("Invalid credentials"));
        driver.quit();
    }
}
